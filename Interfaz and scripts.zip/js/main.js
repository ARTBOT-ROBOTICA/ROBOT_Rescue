navigator.mediaDevices.getUserMedia({video:true}).then((stream)=>{
  console.log(stream)

  let video = document.getElementById('video')

  video.srcObject = stream

  video.onloadedmetadata = (ev) => video.play()

}).catch((err)=>console.log(err))












/*
<?php
if (isset($_POST['LightON']))
{
exec("sudo python /home/pi/light1.py");
}
if (isset($_POST['LightOFF']))
{
exec("sudo python /home/pi/light0.py");
}
if (isset($_POST['Light1ON']))
{
exec("sudo python /home/pi/light11.py");
}
if (isset($_POST['Light1OFF']))
{
exec("sudo python /home/pi/light00.py");
}
if (isset($_POST['Lig']))
{
exec("sudo python /home/pi/lig.py");
}
if (isset($_POST['Lig0']))
{
exec("sudo python /home/pi/Lig0.py");
}
?>*/
